﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Creation
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnend = New System.Windows.Forms.Button()
        Me.btnback = New System.Windows.Forms.Button()
        Me.btncreate = New System.Windows.Forms.Button()
        Me.btnhelp = New System.Windows.Forms.Button()
        Me.btnimport = New System.Windows.Forms.Button()
        Me.rtbbank = New System.Windows.Forms.RichTextBox()
        Me.rtbenter = New System.Windows.Forms.RichTextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Txtnth = New System.Windows.Forms.TextBox()
        Me.btnremove = New System.Windows.Forms.Button()
        Me.OpenFile = New System.Windows.Forms.OpenFileDialog()
        Me.Btnclear = New System.Windows.Forms.Button()
        Me.lblcount = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnend
        '
        Me.btnend.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnend.Location = New System.Drawing.Point(45, 498)
        Me.btnend.Name = "btnend"
        Me.btnend.Size = New System.Drawing.Size(149, 58)
        Me.btnend.TabIndex = 0
        Me.btnend.Text = "End"
        Me.btnend.UseVisualStyleBackColor = True
        '
        'btnback
        '
        Me.btnback.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnback.Location = New System.Drawing.Point(289, 490)
        Me.btnback.Name = "btnback"
        Me.btnback.Size = New System.Drawing.Size(192, 66)
        Me.btnback.TabIndex = 1
        Me.btnback.Text = "Back"
        Me.btnback.UseVisualStyleBackColor = True
        '
        'btncreate
        '
        Me.btncreate.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncreate.ForeColor = System.Drawing.Color.MediumOrchid
        Me.btncreate.Location = New System.Drawing.Point(789, 493)
        Me.btncreate.Name = "btncreate"
        Me.btncreate.Size = New System.Drawing.Size(139, 60)
        Me.btncreate.TabIndex = 2
        Me.btncreate.Text = "CREATE"
        Me.btncreate.UseVisualStyleBackColor = True
        '
        'btnhelp
        '
        Me.btnhelp.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnhelp.ForeColor = System.Drawing.Color.MediumTurquoise
        Me.btnhelp.Location = New System.Drawing.Point(783, 24)
        Me.btnhelp.Name = "btnhelp"
        Me.btnhelp.Size = New System.Drawing.Size(145, 85)
        Me.btnhelp.TabIndex = 3
        Me.btnhelp.Text = "Help"
        Me.btnhelp.UseVisualStyleBackColor = True
        '
        'btnimport
        '
        Me.btnimport.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnimport.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.btnimport.Location = New System.Drawing.Point(783, 136)
        Me.btnimport.Name = "btnimport"
        Me.btnimport.Size = New System.Drawing.Size(145, 87)
        Me.btnimport.TabIndex = 4
        Me.btnimport.Text = "Import"
        Me.btnimport.UseVisualStyleBackColor = True
        '
        'rtbbank
        '
        Me.rtbbank.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.15!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtbbank.Location = New System.Drawing.Point(618, 250)
        Me.rtbbank.Name = "rtbbank"
        Me.rtbbank.Size = New System.Drawing.Size(310, 196)
        Me.rtbbank.TabIndex = 5
        Me.rtbbank.Text = "Word Bank:"
        '
        'rtbenter
        '
        Me.rtbenter.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.15!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtbenter.Location = New System.Drawing.Point(20, 20)
        Me.rtbenter.Name = "rtbenter"
        Me.rtbenter.Size = New System.Drawing.Size(560, 359)
        Me.rtbenter.TabIndex = 6
        Me.rtbenter.Text = "Enter your text here..."
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(15, 403)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(341, 29)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Remove every                    word"
        '
        'Txtnth
        '
        Me.Txtnth.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txtnth.Location = New System.Drawing.Point(194, 400)
        Me.Txtnth.Name = "Txtnth"
        Me.Txtnth.Size = New System.Drawing.Size(78, 30)
        Me.Txtnth.TabIndex = 8
        Me.Txtnth.Text = "nth"
        Me.Txtnth.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnremove
        '
        Me.btnremove.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnremove.ForeColor = System.Drawing.Color.Red
        Me.btnremove.Location = New System.Drawing.Point(394, 390)
        Me.btnremove.Name = "btnremove"
        Me.btnremove.Size = New System.Drawing.Size(138, 56)
        Me.btnremove.TabIndex = 9
        Me.btnremove.Text = "Remove"
        Me.btnremove.UseVisualStyleBackColor = True
        '
        'OpenFile
        '
        Me.OpenFile.FileName = "OpenFileDialog1"
        '
        'Btnclear
        '
        Me.Btnclear.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btnclear.ForeColor = System.Drawing.Color.LimeGreen
        Me.Btnclear.Location = New System.Drawing.Point(618, 97)
        Me.Btnclear.Name = "Btnclear"
        Me.Btnclear.Size = New System.Drawing.Size(108, 80)
        Me.Btnclear.TabIndex = 10
        Me.Btnclear.Text = "Clear Text"
        Me.Btnclear.UseVisualStyleBackColor = True
        '
        'lblcount
        '
        Me.lblcount.AutoSize = True
        Me.lblcount.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcount.Location = New System.Drawing.Point(571, 512)
        Me.lblcount.Name = "lblcount"
        Me.lblcount.Size = New System.Drawing.Size(118, 25)
        Me.lblcount.TabIndex = 11
        Me.lblcount.Text = "Word Count"
        Me.lblcount.Visible = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(626, 24)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(0, 17)
        Me.Label2.TabIndex = 12
        '
        'Creation
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(970, 598)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblcount)
        Me.Controls.Add(Me.Btnclear)
        Me.Controls.Add(Me.btnremove)
        Me.Controls.Add(Me.Txtnth)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.rtbenter)
        Me.Controls.Add(Me.rtbbank)
        Me.Controls.Add(Me.btnimport)
        Me.Controls.Add(Me.btnhelp)
        Me.Controls.Add(Me.btncreate)
        Me.Controls.Add(Me.btnback)
        Me.Controls.Add(Me.btnend)
        Me.Name = "Creation"
        Me.Text = "Creation"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnend As Button
    Friend WithEvents btnback As Button
    Friend WithEvents btncreate As Button
    Friend WithEvents btnhelp As Button
    Friend WithEvents btnimport As Button
    Friend WithEvents rtbbank As RichTextBox
    Friend WithEvents rtbenter As RichTextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Txtnth As TextBox
    Friend WithEvents btnremove As Button
    Friend WithEvents OpenFile As OpenFileDialog
    Friend WithEvents Btnclear As Button
    Friend WithEvents lblcount As Label
    Friend WithEvents Label2 As Label
End Class
