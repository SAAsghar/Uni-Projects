﻿Public Class DoNow2
    Private Sub btnfinish_Click(sender As Object, e As EventArgs) Handles btnfinish.Click
        MsgBox("Congratulations on finishing your cloze passage, show your teacher to get it marked now")
        Finish.Show()
        Close()
    End Sub

    Private Sub btnbank_Click(sender As Object, e As EventArgs) Handles btnbank.Click
        Completion.Show()
        Close()
    End Sub

    Private Sub DoNow2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        rtbbank.Text = Creation.bank
        Dim valu As Integer
        While valu <= Creation.bankarray.Length - 1
            rtbtext.Text = rtbtext.Text & " " & Creation.bankarray(valu)
            valu = valu + 1
        End While
    End Sub

    Private Sub rtbtext_TextChanged(sender As Object, e As EventArgs) Handles rtbtext.TextChanged
        rtbtext.ReadOnly = True
    End Sub

    Private Sub rtbbank_TextChanged(sender As Object, e As EventArgs) Handles rtbbank.TextChanged
        rtbbank.ReadOnly = True
    End Sub

    Private Sub btnhelp_Click(sender As Object, e As EventArgs) Handles btnhelp.Click
        Help2.Show()
        Close()
    End Sub
End Class