﻿Public Class Creation
    Public count As Integer
    Public bankarray() As String
    Private check As Boolean
    Public bank As String
    Public cloze As String
    Public transfer As String


    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnback.Click
        Close()
        Home.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnend.Click
        End
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles btncreate.Click
        Completion.Show()
        Hide()
    End Sub

    Private Sub btnhelp_Click(sender As Object, e As EventArgs) Handles btnhelp.Click
        Help.Show()
        Home.variable = 1
        Close()
    End Sub

    Private Sub RichTextBox1_TextChanged(sender As Object, e As EventArgs) Handles rtbbank.TextChanged

    End Sub

    Private Sub OpenFileDialog1_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles OpenFile.FileOk

    End Sub

    Private Sub btnimport_Click(sender As Object, e As EventArgs) Handles btnimport.Click
        OpenFile.ShowDialog()

    End Sub
    Private Sub OpenFile_FileOk(sender As System.Object, e As System.ComponentModel.CancelEventArgs) Handles OpenFile.FileOk
        Dim path As String
        path = OpenFile.FileName.ToString()

        Dim FileNum As Integer = FreeFile()
        'MsgBox(FileNum)
        Dim TempString As String = "", TempLine As String
        FileOpen(FileNum, path, OpenMode.Input) 'open file
        Do Until EOF(FileNum)   ' read until the end of file is reached
            TempLine = LineInput(FileNum) ' read one line
            ' add each line of text in the file to the temporary
            ' string, include a carriage return and a line(feed)
            TempString += TempLine '+ vbCrLf
        Loop
        FileClose(FileNum)  ' close file
        rtbenter.Text = TempString ' copy the string to the text box

    End Sub

    Private Sub Btnclear_Click(sender As Object, e As EventArgs) Handles Btnclear.Click
        rtbenter.Text = ""

    End Sub

    Private Sub RichTextBox2_TextChanged(sender As Object, e As EventArgs) Handles rtbenter.TextChanged

        Me.count = rtbenter.Text.Split(" ").Length
        lblcount.Text = count - 1
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles Txtnth.TextChanged

    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles btnremove.Click
        If check = False Then
            bankarray = rtbenter.Text.Split(" ")
            check = True
        End If

        
        Dim temparray As String() = bankarray
        rtbenter.Enabled = False
        Btnclear.Enabled = False
        Txtnth.Enabled = False
        btnremove.Enabled = False
        rtbbank.Text = ""

        Dim nth As Integer = Txtnth.Text

        Dim Count As Integer
        Dim text As String
        Dim space As Integer = 1
        text = ""
        While Count <= temparray.Length - 1
            If Count Mod nth = 0 Then
                text = text + vbCrLf + temparray(Count)
                Randomize()
                temparray(Count) = Str(space) + "______"
                space += 1
            End If
            Count += 1

        End While
        Me.cloze = rtbenter.Text

        rtbbank.Text = text
        text = ""
        Count = 0
        While Count <= temparray.Length - 1
            text = text + " " + temparray(Count)
            Count += 1
        End While

        rtbenter.Text = text
        Me.bank = rtbbank.Text

    End Sub

    Private Sub lblcount_Click(sender As Object, e As EventArgs) Handles lblcount.Click
        Visible = False
    End Sub

    Private Sub Creation_Load(sender As Object, e As EventArgs) Handles Me.Load

    End Sub
End Class
