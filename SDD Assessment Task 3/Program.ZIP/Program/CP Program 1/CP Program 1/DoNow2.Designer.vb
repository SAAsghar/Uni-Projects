﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DoNow2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnbank = New System.Windows.Forms.Button()
        Me.btnfinish = New System.Windows.Forms.Button()
        Me.rtbtext = New System.Windows.Forms.RichTextBox()
        Me.rtbbank = New System.Windows.Forms.RichTextBox()
        Me.rtbanswer = New System.Windows.Forms.RichTextBox()
        Me.btnhelp = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnbank
        '
        Me.btnbank.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnbank.ForeColor = System.Drawing.Color.CornflowerBlue
        Me.btnbank.Location = New System.Drawing.Point(40, 458)
        Me.btnbank.Name = "btnbank"
        Me.btnbank.Size = New System.Drawing.Size(168, 78)
        Me.btnbank.TabIndex = 0
        Me.btnbank.Text = "Back"
        Me.btnbank.UseVisualStyleBackColor = True
        '
        'btnfinish
        '
        Me.btnfinish.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnfinish.ForeColor = System.Drawing.Color.Crimson
        Me.btnfinish.Location = New System.Drawing.Point(835, 465)
        Me.btnfinish.Name = "btnfinish"
        Me.btnfinish.Size = New System.Drawing.Size(205, 75)
        Me.btnfinish.TabIndex = 1
        Me.btnfinish.Text = "FINISH"
        Me.btnfinish.UseVisualStyleBackColor = True
        '
        'rtbtext
        '
        Me.rtbtext.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtbtext.Location = New System.Drawing.Point(30, 39)
        Me.rtbtext.Name = "rtbtext"
        Me.rtbtext.Size = New System.Drawing.Size(379, 383)
        Me.rtbtext.TabIndex = 2
        Me.rtbtext.Text = ""
        '
        'rtbbank
        '
        Me.rtbbank.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtbbank.Location = New System.Drawing.Point(438, 39)
        Me.rtbbank.Name = "rtbbank"
        Me.rtbbank.Size = New System.Drawing.Size(299, 383)
        Me.rtbbank.TabIndex = 3
        Me.rtbbank.Text = ""
        '
        'rtbanswer
        '
        Me.rtbanswer.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtbanswer.Location = New System.Drawing.Point(770, 39)
        Me.rtbanswer.Name = "rtbanswer"
        Me.rtbanswer.Size = New System.Drawing.Size(312, 383)
        Me.rtbanswer.TabIndex = 4
        Me.rtbanswer.Text = ""
        '
        'btnhelp
        '
        Me.btnhelp.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnhelp.ForeColor = System.Drawing.Color.DarkOrchid
        Me.btnhelp.Location = New System.Drawing.Point(438, 458)
        Me.btnhelp.Name = "btnhelp"
        Me.btnhelp.Size = New System.Drawing.Size(206, 78)
        Me.btnhelp.TabIndex = 5
        Me.btnhelp.Text = "Help"
        Me.btnhelp.UseVisualStyleBackColor = True
        '
        'DoNow2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1098, 561)
        Me.Controls.Add(Me.btnhelp)
        Me.Controls.Add(Me.rtbanswer)
        Me.Controls.Add(Me.rtbbank)
        Me.Controls.Add(Me.rtbtext)
        Me.Controls.Add(Me.btnfinish)
        Me.Controls.Add(Me.btnbank)
        Me.Name = "DoNow2"
        Me.Text = "DoNow2"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnbank As Button
    Friend WithEvents btnfinish As Button
    Friend WithEvents rtbtext As RichTextBox
    Friend WithEvents rtbbank As RichTextBox
    Friend WithEvents rtbanswer As RichTextBox
    Friend WithEvents btnhelp As Button
End Class
