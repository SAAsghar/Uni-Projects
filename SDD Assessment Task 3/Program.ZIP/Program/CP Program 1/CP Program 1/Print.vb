﻿Public Class Print
    Private Sub btnback_Click(sender As Object, e As EventArgs) Handles btnback.Click
        Completion.Show()
        Close()
    End Sub

    Private Sub btnprint_Click(sender As Object, e As EventArgs) Handles btnprint.Click
        PrintDocument1.PrinterSettings.Copies = 1
        PrintDocument1.Print()
    End Sub

    Private Sub rtb1_TextChanged(sender As Object, e As EventArgs) Handles rtb1.TextChanged
        rtb1.ReadOnly = True
    End Sub

    Private Sub rtb2_TextChanged(sender As Object, e As EventArgs) Handles rtb2.TextChanged
        rtb2.ReadOnly = True
    End Sub

    Private Sub btnend_Click(sender As Object, e As EventArgs) Handles btnend.Click
        End
    End Sub

    Private Sub Print_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        rtb2.Text = Creation.bank
        Dim valu As Integer
        While valu <= Creation.bankarray.Length - 1
            rtb1.Text = rtb1.Text & " " & Creation.bankarray(valu)
            valu = valu + 1
        End While
    End Sub

    Private Sub PrintDocument1_PrintPage_1(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        Dim outstring As String
        outstring = rtb1.Text & vbCrLf & vbCrLf & rtb2.Text
        e.Graphics.DrawString(outstring, rtb1.Font, Brushes.Black, 100, 100)
    End Sub
End Class