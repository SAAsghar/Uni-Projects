﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Print
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.rtb1 = New System.Windows.Forms.RichTextBox()
        Me.rtb2 = New System.Windows.Forms.RichTextBox()
        Me.btnback = New System.Windows.Forms.Button()
        Me.btnprint = New System.Windows.Forms.Button()
        Me.btnend = New System.Windows.Forms.Button()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.SuspendLayout()
        '
        'rtb1
        '
        Me.rtb1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtb1.Location = New System.Drawing.Point(25, 30)
        Me.rtb1.Name = "rtb1"
        Me.rtb1.Size = New System.Drawing.Size(443, 289)
        Me.rtb1.TabIndex = 0
        Me.rtb1.Text = ""
        '
        'rtb2
        '
        Me.rtb2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtb2.Location = New System.Drawing.Point(495, 30)
        Me.rtb2.Name = "rtb2"
        Me.rtb2.Size = New System.Drawing.Size(283, 289)
        Me.rtb2.TabIndex = 1
        Me.rtb2.Text = ""
        '
        'btnback
        '
        Me.btnback.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnback.ForeColor = System.Drawing.Color.Crimson
        Me.btnback.Location = New System.Drawing.Point(54, 351)
        Me.btnback.Name = "btnback"
        Me.btnback.Size = New System.Drawing.Size(167, 61)
        Me.btnback.TabIndex = 2
        Me.btnback.Text = "Back"
        Me.btnback.UseVisualStyleBackColor = True
        '
        'btnprint
        '
        Me.btnprint.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnprint.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.btnprint.Location = New System.Drawing.Point(527, 347)
        Me.btnprint.Name = "btnprint"
        Me.btnprint.Size = New System.Drawing.Size(210, 73)
        Me.btnprint.TabIndex = 3
        Me.btnprint.Text = "Print text"
        Me.btnprint.UseVisualStyleBackColor = True
        '
        'btnend
        '
        Me.btnend.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnend.ForeColor = System.Drawing.Color.MediumOrchid
        Me.btnend.Location = New System.Drawing.Point(316, 351)
        Me.btnend.Name = "btnend"
        Me.btnend.Size = New System.Drawing.Size(134, 66)
        Me.btnend.TabIndex = 4
        Me.btnend.Text = "END"
        Me.btnend.UseVisualStyleBackColor = True
        '
        'PrintDocument1
        '
        '
        'Print
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnend)
        Me.Controls.Add(Me.btnprint)
        Me.Controls.Add(Me.btnback)
        Me.Controls.Add(Me.rtb2)
        Me.Controls.Add(Me.rtb1)
        Me.Name = "Print"
        Me.Text = "Print"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents rtb1 As RichTextBox
    Friend WithEvents rtb2 As RichTextBox
    Friend WithEvents btnback As Button
    Friend WithEvents btnprint As Button
    Friend WithEvents btnend As Button
    Friend WithEvents PrintDocument1 As Printing.PrintDocument
End Class
