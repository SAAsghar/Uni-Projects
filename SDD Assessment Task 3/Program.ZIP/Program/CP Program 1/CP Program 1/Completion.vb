﻿Public Class Completion
    Private Sub btnnow_Click(sender As Object, e As EventArgs) Handles btnnow.Click
        DoNow2.Show()
        Hide()
    End Sub

    Private Sub btnsave_Click(sender As Object, e As EventArgs) Handles btnsave.Click
        Print.Show()
        Hide()
    End Sub
End Class