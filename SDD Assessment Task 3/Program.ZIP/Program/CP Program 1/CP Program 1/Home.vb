﻿Public Class Home
    Public variable As Boolean = 1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnstart.Click
        Creation.Show()
        Me.Hide()
    End Sub

    Private Sub btnclose_Click(sender As Object, e As EventArgs) Handles btnclose.Click
        End
    End Sub

    Private Sub btnhelp_Click(sender As Object, e As EventArgs) Handles btnhelp.Click
        variable = 0
        Help.Show()
        Hide()

    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs)
        Finish.Show()
    End Sub
End Class
